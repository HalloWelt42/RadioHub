<script lang="ts">
  // Eigene Ansicht fürs Telefon: Reiter unten (Bereiche der App, Aufträge, Mehr), Band bei fehlender Verbindung.
  // Höhe, Kopf, Fußleiste und sichere Ränder kommen allein aus stil/rahmen.css (data-rahmen), wie in jeder Telefonansicht.
  import { onMount } from "svelte";
  import { fest } from "../../lib/stelle.svelte";
  import AnfrageOeffnen from "../AnfrageOeffnen.svelte";
  import AppWeg from "../AppWeg.svelte";
  import { verbindung } from "../../lib/erreichbar.svelte";
  import { auftraege, verfolgen } from "../../lib/auftraege.svelte";
  import { fassung } from "../../lib/fassung.svelte";
  import { gehe, navigation } from "../../lib/navigation.svelte";
  import type { Anfrage, Bereich, EinstellungsReiter } from "../../lib/typen";
  import { gestoert, verbindungen, verbindungenVerfolgen } from "../../lib/verbindungen.svelte";
  import Vermisst from "../Vermisst.svelte";
  import Einstellungen from "../Einstellungen.svelte";
  import Protokoll from "../Protokoll.svelte";
  import MobilAuftraege from "./MobilAuftraege.svelte";
  import MobilMehr from "./MobilMehr.svelte";

  let { bereiche, oeffnen, einstellungen = [], auftraegeReiter = true }: {
    bereiche: Bereich[]; oeffnen?: (a: Anfrage) => Promise<string> | string; einstellungen?: EinstellungsReiter[];
    auftraegeReiter?: boolean } = $props();

  onMount(() => {
    const a = verfolgen();
    const v = verbindungenVerfolgen();
    return () => {
      a();
      v();
    };
  });

  const reiter = $derived(bereiche.some((b) => b.reiter) ? bereiche.filter((b) => b.reiter) : bereiche.slice(0, 2));
  const weitere = $derived(bereiche.filter((b) => !reiter.includes(b)));
  const seite = $derived(navigation.seite || reiter[0]?.schluessel || "auftraege");
  const bereich = $derived(bereiche.find((b) => b.schluessel === seite));
  const unterMehr = $derived(seite === "protokoll" || seite === "einstellungen" || (seite === "auftraege" && !auftraegeReiter)
                             || weitere.some((b) => b.schluessel === seite));
  const titel = $derived(bereich?.titel ?? ({ auftraege: "Aufträge", protokoll: "Protokoll", einstellungen: "Einstellungen", mehr: "Mehr" } as Record<string, string>)[seite] ?? "");
  const fehlend = $derived(verbindungen.liste.filter(gestoert));   // vermisste zeigt nur das Minisymbol im Kopf
  const offen = $derived(auftraege.laufen + auftraege.warten);

  // Mehr ist ein Menü (WIKI-76): der erste Tipp öffnet es und merkt sich, woher man kam; der zweite schließt es und
  // führt dorthin zurück (ein Schritt zurück im Verlauf, damit "Zurück" danach nicht wieder im Menü landet). Ohne
  // Herkunft (etwa nach dem Neuladen auf /mehr) geht es zum ersten Reiter.
  let vorMehr = false;
  function mehrTippen() {
    if (seite !== "mehr") {
      vorMehr = true;
      gehe("mehr");
    } else if (vorMehr) {
      vorMehr = false;
      history.back();
    } else {
      gehe(reiter[0]?.schluessel ?? "auftraege");
    }
  }
  $effect(() => {
    if (seite !== "mehr") vorMehr = false;           // anders verlassen (Eintrag gewählt, Zurück): nichts mehr zu schließen
  });
</script>

<div class="mobil" data-rahmen="app">
  <div class="t-kopf" data-rahmen="kopf" use:fest={"oben"} class:mit-aktionen={!!navigation.aktionen}>
    {#if bereich && navigation.teile.length}
      <button class="rund" aria-label="Zurück" onclick={() => gehe(seite)}><i class="fa-solid fa-chevron-left"></i></button>
    {:else if unterMehr}<button class="rund" aria-label="Zurück" onclick={() => gehe("mehr")}><i class="fa-solid fa-chevron-left"></i></button>{/if}
    <h1>{navigation.titel || titel}</h1>
    {#if navigation.kennzeichen}<span class="pille"><i class="fa-solid {navigation.kennzeichen.symbol}"></i>{navigation.kennzeichen.text}</span>{/if}
    {#if navigation.aktionen}<span class="t-aktionen">{@render navigation.aktionen()}</span>{/if}
    <Vermisst />
    {#if offen && seite !== "auftraege"}<button class="pille aktiv" style="border:0" onclick={() => gehe("auftraege")}><i class="fa-solid fa-gears"></i>{offen}</button>{/if}
  </div>
  {#if !verbindung.ok}
    <AppWeg kompakt />
  {:else if fassung.neu}
    <div class="t-band"><i class="fa-solid fa-rotate" style="margin-top:3px"></i>
      <span style="flex:1">Neue Fassung {fassung.neu}; lädt beim nächsten Wechsel von selbst.</span>
      <button class="rund" aria-label="Jetzt neu laden" onclick={() => location.reload()}><i class="fa-solid fa-rotate"></i></button></div>
  {/if}
  {#if verbindung.ok && fehlend.length}
    <div class="t-band"><i class="fa-solid fa-triangle-exclamation" style="margin-top:3px"></i>
      <span>{#each fehlend as v, i (v.name)}{i ? " " : ""}{`${v.name} nicht erreichbar; nichts geht verloren.`}{/each}</span></div>
  {/if}
  <div class="t-inhalt" data-rahmen="inhalt">
    {#if bereich}
      <bereich.seite />
    {:else if seite === "anfrage" && oeffnen}
      <AnfrageOeffnen {oeffnen} />
    {:else if seite === "protokoll"}
      <Protokoll kompakt />
    {:else if seite === "einstellungen"}
      <Einstellungen reiter={einstellungen} />
    {:else if seite === "mehr"}
      <MobilMehr {weitere} auftraege={!auftraegeReiter} />
    {:else}
      <MobilAuftraege />
    {/if}
  </div>
  <nav class="t-reiter" data-rahmen="fuss" use:fest={"unten"}>
    {#each reiter as b (b.schluessel)}
      <button class:aktiv={seite === b.schluessel} onclick={() => gehe(b.schluessel)}><i class="fa-solid {b.symbol}"></i><span class="t-reiter-name">{b.kurz ?? b.titel}</span></button>
    {/each}
    {#if auftraegeReiter}<button class:aktiv={seite === "auftraege"} onclick={() => gehe("auftraege")}><i class="fa-solid fa-list-check"></i><span class="t-reiter-name">Aufträge</span></button>{/if}
    <button class:aktiv={seite === "mehr" || unterMehr} aria-expanded={seite === "mehr"} title={seite === "mehr" ? "Menü schließen" : "Mehr"}
            onclick={mehrTippen}><i class="fa-solid {seite === 'mehr' ? 'fa-xmark' : 'fa-ellipsis'}"></i><span class="t-reiter-name">Mehr</span></button>
  </nav>
</div>
