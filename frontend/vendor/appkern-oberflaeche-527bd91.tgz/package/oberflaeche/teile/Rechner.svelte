<script lang="ts">
  // Ansicht am Rechner: Kopf, Band (App antwortet nicht, neue Fassung oder fehlende Verbindung), Navigation, Seite
  // (Aufträge mit Leiste).
  import { onMount } from "svelte";
  import AnfrageOeffnen from "./AnfrageOeffnen.svelte";
  import AppWeg from "./AppWeg.svelte";
  import { verbindung } from "../lib/erreichbar.svelte";
  import { verfolgen } from "../lib/auftraege.svelte";
  import { fassung, ruhig } from "../lib/fassung.svelte";
  import { navigation } from "../lib/navigation.svelte";
  import type { Anfrage, Bereich, EinstellungsReiter } from "../lib/typen";
  import { gestoert, verbindungen, verbindungenVerfolgen } from "../lib/verbindungen.svelte";
  import Auftraege from "./Auftraege.svelte";
  import Band from "./Band.svelte";
  import Einstellungen from "./Einstellungen.svelte";
  import Kopf from "./Kopf.svelte";
  import Navigation from "./Navigation.svelte";
  import Protokoll from "./Protokoll.svelte";
  import Fuss from "./Fuss.svelte";
  import type { Snippet } from "svelte";
  import { anzeige } from "../lib/anzeige.svelte";

  // `kopf`, `kopfMitte`, `navigation`, `fuss`: was die App in Kopf (rechts und Mitte), Seitenleiste (unter den
  // Bereichen) und Fußleiste zeigt
  let { bereiche, oeffnen, einstellungen = [], kopf, kopfMitte, navigation: navZusatz, fuss }: {
    bereiche: Bereich[]; oeffnen?: (a: Anfrage) => Promise<string> | string; einstellungen?: EinstellungsReiter[];
    kopf?: Snippet; kopfMitte?: Snippet; navigation?: Snippet; fuss?: Snippet } = $props();

  onMount(() => {
    const auftraegeStoppen = verfolgen();
    const verbindungenStoppen = verbindungenVerfolgen();
    return () => {
      auftraegeStoppen();
      verbindungenStoppen();
    };
  });

  const seite = $derived(navigation.seite || bereiche[0]?.schluessel || "auftraege");
  const bereich = $derived(bereiche.find((b) => b.schluessel === seite));
  const fehlend = $derived(verbindungen.liste.filter(gestoert));   // vermisste zeigt nur das Minisymbol im Kopf (WIKI-68)
</script>

<div class="fenster-voll">
  <Kopf rechts={kopf} mitte={kopfMitte} />
  {#if !verbindung.ok}
    <AppWeg />
  {:else if fassung.neu}
    <div class="band">
      <i class="fa-solid fa-rotate"></i>
      <span><b>Neue Fassung {fassung.neu} ist da.</b>
        {ruhig() ? "Beim nächsten Seitenwechsel lädt die App sie von selbst." : "Sie lädt von selbst, sobald die laufende Arbeit hier fertig ist."}</span>
      <button class="knopf" onclick={() => location.reload()}><i class="fa-solid fa-rotate"></i> Jetzt neu laden</button>
    </div>
  {:else if fehlend.length}<Band verbindungen={fehlend} />{:else}<div></div>{/if}
  <div class="geruest" class:mit-leiste={!bereich && seite === "auftraege"} class:eingeklappt={anzeige.eingeklappt}>
    <Navigation {bereiche} {seite} zusatz={navZusatz} />
    {#if bereich}
      <section class="seite"><bereich.seite /></section>
    {:else if seite === "anfrage" && oeffnen}
      <section class="seite"><AnfrageOeffnen {oeffnen} /></section>
    {:else if seite === "protokoll"}
      <Protokoll />
    {:else if seite === "einstellungen"}
      <Einstellungen reiter={einstellungen} />
    {:else}
      <Auftraege />
    {/if}
  </div>
  <Fuss rechts={fuss} />
</div>
